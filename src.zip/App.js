import React from "react";
import Started from "./src/Started";
import Login from "./src/Login";
import Home from "./src/Home";
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator} from "@react-navigation/native-stack";
import { useFonts } from "expo-font";
import AppLoading from "expo-app-loading";

const Stack = createNativeStackNavigator();

export default function App() {

  const [fontLoaded] = useFonts({
    'poppins': require('./assets/fonts/Poppins-Medium.ttf')
  })
  if(!fontLoaded){
    return <AppLoading />
  }
  return (
    <NavigationContainer>{
      <Stack.Navigator initialRouteName="Home">

        <Stack.Screen name="Started" component={Started} />

        <Stack.Screen name="Login" component={Login} />

        <Stack.Screen name="Home" component={Home} />


      </Stack.Navigator>
      
      }</NavigationContainer>
  );
}