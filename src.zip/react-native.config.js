module.exports={
    project:{
        ios:{},
        andriod:{},
    },
    assets:["./assets/fonts"],
}