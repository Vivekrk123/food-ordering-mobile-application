import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const CategoriesCard = (props) => {
    console.log(props.name);
  return (
    <View style={styles.card}>
      <Image source={{ uri: props.image }} style={styles.image} />
      <Image source={require('../assets/canteen.png')}>
      </Image>
      <Text style={styles.name}>{props.name}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    elevation: 5,
    margin: 10,
    shadowColor: '#000',
    width: 96,
    height: 96,
    shadowOffset: {
    width: 0,
    height: 8,
    },
    shadowOpacity:0.02,
    shadowRadius:8,
  },
  image: {
    width: 81,
    height: 75,
    borderRadius: 13,
  },
  name: {
    fontSize: 12,
    fontWeight: 600,
    textAlign: 'center',
    width: 67,
    height: 18,
    fontFamily: 'Poppins',
    lineHeight: 18,
    color: '#333333',
  },
});

export default CategoriesCard;
