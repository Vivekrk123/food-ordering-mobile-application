import React, { useState } from 'react';
import { View , Text ,Image , TextInput, StyleSheet } from 'react-native';

const SearchBar = ({ onSearch }) => {
  const [query, setQuery] = useState('');

  const handleSearch = () => {
    onSearch(query);
  };

  return (
    <View style={styles.container}>
      <View>
      <Text>SearchBar</Text>
      </View>
      <TextInput
      style={styles.searchBar}
      placeholder="Search"
      value={query}
      onChangeText={setQuery}
      onSubmitEditing={handleSearch}
      returnKeyType="search"
      />
    </View>
      
  );
};

const styles = StyleSheet.create({
  searchBar: {
    height: 40,
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
});

export default SearchBar;